const state = {
  moisture: 48,
  temperature: 24.5,
  humidity: 61,
  waterUsed: 0,
  events: 0,
  pump: false,
  history: [],
  lastWatering: "Never"
};

const $ = id => document.getElementById(id);

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number(value) || min));
}

function updateDashboard() {
  $("moisture").textContent = `${state.moisture}%`;
  $("temperature").textContent = `${state.temperature.toFixed(1)} °C`;
  $("humidity").textContent = `${state.humidity}%`;
  $("waterUsed").textContent = state.waterUsed.toFixed(2);
  $("totalWater").textContent = state.waterUsed.toFixed(2);
  $("events").textContent = state.events;
  $("pumpStatus").textContent = state.pump ? "ON" : "OFF";
  $("pumpStatus").style.color = state.pump ? "#b02a2a" : "#287443";
  $("lastWatering").textContent = state.lastWatering;
  $("moistureBar").style.width = `${state.moisture}%`;

  const avg = state.history.length
    ? state.history.reduce((a, b) => a + b.moisture, 0) / state.history.length
    : 0;
  $("averageMoisture").textContent = Math.round(avg);

  drawChart();
  renderTable();
}

function addReading() {
  const now = new Date();
  state.history.push({
    time: now.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit", second: "2-digit"}),
    moisture: state.moisture,
    temperature: state.temperature,
    humidity: state.humidity,
    pump: state.pump ? "ON" : "OFF"
  });
  if (state.history.length > 20) state.history.shift();
}

function renderTable() {
  $("historyTable").innerHTML = state.history.slice().reverse().map(row => `
    <tr>
      <td>${row.time}</td>
      <td>${row.moisture}%</td>
      <td>${row.temperature.toFixed(1)} °C</td>
      <td>${row.humidity}%</td>
      <td>${row.pump}</td>
    </tr>
  `).join("");
}

function drawChart() {
  const canvas = $("chart");
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  ctx.strokeStyle = "#d7dfda";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = 25 + i * 60;
    ctx.beginPath();
    ctx.moveTo(45, y);
    ctx.lineTo(w - 20, y);
    ctx.stroke();
    ctx.fillStyle = "#64736a";
    ctx.fillText(`${100 - i * 25}%`, 5, y + 4);
  }

  if (state.history.length < 2) return;

  ctx.strokeStyle = "#247a45";
  ctx.lineWidth = 3;
  ctx.beginPath();

  state.history.forEach((r, i) => {
    const x = 45 + i * ((w - 70) / Math.max(1, state.history.length - 1));
    const y = 25 + (100 - r.moisture) * 2.4;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();
}

$("mode").addEventListener("change", () => {
  const scheduled = $("mode").value === "schedule";
  $("scheduleControls").classList.toggle("hidden", !scheduled);
  $("autoControls").classList.toggle("hidden", scheduled);
});

$("crop").addEventListener("change", () => {
  $("cropStatus").textContent = $("crop").value;
});

$("save").addEventListener("click", () => {
  const mode = $("mode").value;
  if (mode === "auto") {
    const threshold = clamp($("threshold").value, 10, 90);
    const duration = clamp($("duration").value, 1, 300);
    $("threshold").value = threshold;
    $("duration").value = duration;
    $("message").textContent =
      `Smart mode saved: water below ${threshold}% for ${duration} seconds.`;
  } else if (mode === "schedule") {
    const interval = clamp($("interval").value, 1, 168);
    $("interval").value = interval;
    $("message").textContent =
      `Schedule saved: ${$("startTime").value}, every ${interval} hours.`;
  } else {
    $("message").textContent = "Manual mode selected.";
  }

  // Later this will send settings to the ESP32.
});

$("waterNow").addEventListener("click", () => {
  startWatering(20);
});

function startWatering(seconds) {
  state.pump = true;
  state.events++;
  state.waterUsed += 0.25;
  state.moisture = Math.min(100, state.moisture + 12);
  state.lastWatering = new Date().toLocaleTimeString();
  addReading();
  updateDashboard();

  $("message").textContent =
    `Pump activated for ${seconds} seconds.`;

  setTimeout(() => {
    state.pump = false;
    addReading();
    updateDashboard();
    $("message").textContent = "Watering cycle completed.";
  }, seconds * 1000);
}

// Demo sensor simulation.
// Replace this later with real ESP32 data.
setInterval(() => {
  if (!state.pump) {
    state.moisture = Math.max(15, state.moisture - Math.random() * 2);
  }
  state.temperature = 23 + Math.random() * 5;
  state.humidity = 55 + Math.random() * 15;

  const threshold = clamp($("threshold").value, 10, 90);
  if ($("mode").value === "auto" && state.moisture < threshold && !state.pump) {
    startWatering(clamp($("duration").value, 1, 300));
  } else {
    addReading();
    updateDashboard();
  }
}, 5000);

// ESP32 connection placeholder.
// Example future endpoint:
// fetch("http://ESP32-IP/data").then(r => r.json()).then(data => {...});
function setESP32Status(online) {
  const badge = $("connection");
  badge.textContent = online ? "ESP32 Online" : "ESP32 Offline";
  badge.className = `badge ${online ? "online" : "offline"}`;
}

setESP32Status(false);
addReading();
updateDashboard();
