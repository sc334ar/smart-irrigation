const STORAGE_KEY = "smartfarm_multi_system_v1";

const defaultSystems = [
  {id:"system-1",name:"Greenhouse A",location:"Main Farm",online:true,moisture:48,temp:24.5,humidity:61,tank:82,pump:false,waterUsed:0,events:0,threshold:35,duration:20,mode:"smart",startTime:"07:00",intervalHours:6,crop:"Beans",apiUrl:"",history:[],measurements:[]},
  {id:"system-2",name:"Vegetable Garden",location:"Main Farm",online:true,moisture:57,temp:23.2,humidity:66,tank:74,pump:false,waterUsed:0,events:0,threshold:40,duration:15,mode:"smart",startTime:"08:00",intervalHours:8,crop:"Vegetables",apiUrl:"",history:[],measurements:[]}
];

let systems = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null") || defaultSystems;
let selectedId = systems[0].id;
let wateringTimer = null;

function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(systems)); }

function selected(){ return systems.find(s=>s.id===selectedId) || systems[0]; }

function renderSystemCards(){
  const grid = document.getElementById("systemGrid");
  grid.innerHTML = systems.map(s=>`
    <div class="system-card ${s.id===selectedId?'active':''}" data-id="${s.id}">
      <div class="system-top"><h3>${escapeHtml(s.name)}</h3><span><span class="dot ${s.online?'online':'offline'}"></span>${s.online?'Online':'Offline'}</span></div>
      <p>${escapeHtml(s.location)}</p>
      <p>💧 Soil: <strong>${Math.round(s.moisture)}%</strong> &nbsp; 🚰 Tank: <strong>${Math.round(s.tank)}%</strong></p>
      <p>⚙️ Pump: <strong>${s.pump?'ON':'OFF'}</strong></p>
    </div>`).join("");
  grid.querySelectorAll(".system-card").forEach(c=>c.onclick=()=>{selectedId=c.dataset.id; loadSelected();});
  const select=document.getElementById("systemSelect");
  select.innerHTML=systems.map(s=>`<option value="${s.id}">${escapeHtml(s.name)}</option>`).join("");
  select.value=selectedId;
}

function loadSelected(){
  const s=selected();
  renderSystemCards();
  document.getElementById("selectedSummary").textContent=`${s.name} • ${s.location}`;
  const status=document.getElementById("selectedStatus");
  status.textContent=s.online?"Online":"Offline";
  status.className=`status-pill ${s.online?'online':'offline'}`;
  document.getElementById("moisture").textContent=`${Math.round(s.moisture)}%`;
  document.getElementById("temperature").textContent=`${s.temp.toFixed(1)}°C`;
  document.getElementById("humidity").textContent=`${Math.round(s.humidity)}%`;
  document.getElementById("tank").textContent=`${Math.round(s.tank)}%`;
  document.getElementById("pump").textContent=s.pump?"ON":"OFF";
  document.getElementById("waterUsed").textContent=`${s.waterUsed.toFixed(2)} L`;
  document.getElementById("mode").value=s.mode;
  document.getElementById("threshold").value=s.threshold;
  document.getElementById("duration").value=s.duration;
  document.getElementById("startTime").value=s.startTime;
  document.getElementById("intervalHours").value=s.intervalHours;
  document.getElementById("crop").value=s.crop;
  document.getElementById("apiUrl").value=s.apiUrl||"";
  document.getElementById("apiMode").textContent=s.apiUrl?"Live API configured":"Demo data";
  drawChart(s);
  renderMeasurements();
  renderSummary();
}

function renderSummary(){
  document.getElementById("totalSystems").textContent=systems.length;
  document.getElementById("onlineSystems").textContent=systems.filter(s=>s.online).length;
  document.getElementById("totalEvents").textContent=systems.reduce((a,s)=>a+s.events,0);
  document.getElementById("totalWater").textContent=systems.reduce((a,s)=>a+s.waterUsed,0).toFixed(2)+" L";
}

function recordMeasurement(s){
  const item={time:new Date().toLocaleTimeString(),moisture:s.moisture,temp:s.temp,humidity:s.humidity,pump:s.pump};
  s.measurements.unshift(item);
  s.measurements=s.measurements.slice(0,10);
  s.history.push({time:Date.now(),value:s.moisture});
  s.history=s.history.slice(-30);
}

function simulate(){
  systems.forEach(s=>{
    if(!s.online) return;
    const drift=(Math.random()-0.53)*2.2;
    s.moisture=Math.max(10,Math.min(90,s.moisture+drift));
    s.temp=Math.max(16,Math.min(35,s.temp+(Math.random()-0.5)*0.3));
    s.humidity=Math.max(30,Math.min(90,s.humidity+(Math.random()-0.5)*1.2));
    if(!s.pump) s.tank=Math.max(0,s.tank-0.03);
    recordMeasurement(s);
    if(s.mode==="smart" && s.moisture < s.threshold && !s.pump && s.tank>5) startWatering(s.id);
  });
  saveState();
  loadSelected();
}

function startWatering(id){
  const s=systems.find(x=>x.id===id);
  if(!s || s.pump || s.tank<=0) return;
  s.pump=true; s.events++; s.waterUsed+=0.25; s.tank=Math.max(0,s.tank-1.5);
  s.moisture=Math.min(95,s.moisture+12);
  saveState(); loadSelected();
  clearTimeout(wateringTimer);
  if(id===selectedId) document.getElementById("message").textContent=`${s.name}: watering started.`;
  wateringTimer=setTimeout(()=>{
    s.pump=false; saveState(); loadSelected();
    if(id===selectedId) document.getElementById("message").textContent=`${s.name}: watering finished.`;
  }, Math.max(1000, s.duration*1000));
}

function drawChart(s){
  const canvas=document.getElementById("moistureChart"), ctx=canvas.getContext("2d");
  const w=canvas.width, h=canvas.height;
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle="#dfe9e2"; ctx.lineWidth=1;
  for(let i=0;i<=4;i++){const y=25+i*(h-50)/4;ctx.beginPath();ctx.moveTo(45,y);ctx.lineTo(w-20,y);ctx.stroke();}
  const vals=s.history.length?s.history.map(x=>x.value):[s.moisture];
  ctx.strokeStyle="#247a49";ctx.lineWidth=3;ctx.beginPath();
  vals.forEach((v,i)=>{
    const x=45+(i/Math.max(1,vals.length-1))*(w-70);
    const y=h-25-(v/100)*(h-50);
    if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);
  });ctx.stroke();
  ctx.fillStyle="#52655a";ctx.font="12px Arial";
  [0,25,50,75,100].forEach((v,i)=>ctx.fillText(v+"%",8,h-25-i*(h-50)/4+4));
}

function renderMeasurements(){
  const rows=[];
  systems.forEach(s=>s.measurements.slice(0,3).forEach(m=>rows.push({name:s.name,...m})));
  rows.sort((a,b)=>a.time<b.time?1:-1);
  document.getElementById("measurements").innerHTML=rows.slice(0,12).map(m=>`<tr><td>${escapeHtml(m.name)}</td><td>${m.time}</td><td>${Math.round(m.moisture)}%</td><td>${m.temp.toFixed(1)}°C</td><td>${Math.round(m.humidity)}%</td><td>${m.pump?'ON':'OFF'}</td></tr>`).join("");
}

function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

document.getElementById("systemSelect").onchange=e=>{selectedId=e.target.value;loadSelected();};

document.getElementById("addSystemBtn").onclick=()=>{
  const number=systems.length+1;
  const s={id:"system-"+Date.now(),name:"Irrigation System "+number,location:"New Zone",online:true,moisture:50,temp:24,humidity:60,tank:80,pump:false,waterUsed:0,events:0,threshold:35,duration:20,mode:"smart",startTime:"07:00",intervalHours:6,crop:"Vegetables",apiUrl:"",history:[],measurements:[]};
  systems.push(s);selectedId=s.id;saveState();loadSelected();
};

document.getElementById("saveBtn").onclick=()=>{
  const s=selected();
  s.mode=document.getElementById("mode").value;
  s.threshold=Number(document.getElementById("threshold").value);
  s.duration=Number(document.getElementById("duration").value);
  s.startTime=document.getElementById("startTime").value;
  s.intervalHours=Number(document.getElementById("intervalHours").value);
  s.crop=document.getElementById("crop").value;
  s.apiUrl=document.getElementById("apiUrl").value.trim();
  saveState();loadSelected();
  document.getElementById("message").textContent=`Settings saved for ${s.name}.`;
};

document.getElementById("waterBtn").onclick=()=>startWatering(selectedId);

document.getElementById("testApiBtn").onclick=async()=>{
  const s=selected(), msg=document.getElementById("apiMessage");
  if(!s.apiUrl){msg.textContent="Add an API URL first. The dashboard is currently using demo data.";return;}
  msg.textContent="Testing API…";
  try{
    const r=await fetch(s.apiUrl,{method:"GET"});
    msg.textContent=r.ok?"API responded successfully.":"API responded with status "+r.status+".";
  }catch(e){msg.textContent="Could not reach the API from this browser. This is common with local ESP32 HTTP addresses on an HTTPS GitHub Pages site; a cloud API is recommended for the live version.";}
};

systems.forEach(s=>{if(!s.history.length){for(let i=0;i<12;i++){s.history.push({time:Date.now()-((11-i)*5000),value:s.moisture+(Math.random()-0.5)*8});}recordMeasurement(s);}});
loadSelected();
setInterval(simulate,5000);
