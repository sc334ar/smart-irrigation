# SmartFarm Irrigation — Multi-System Dashboard

This version upgrades the dashboard to support multiple irrigation systems from one website.

## Included
- Multiple ESP32/Arduino system cards
- System selector
- Separate soil moisture, temperature, humidity, tank, pump and water-use data
- Separate irrigation settings for each system
- Manual watering button
- Smart moisture mode
- Scheduled settings
- API URL field for future live connections
- Multi-system science-fair totals
- Demo sensor simulation when hardware is not connected

## Important
GitHub Pages hosts the front-end only. It does not provide a database or server for ESP32 devices.

For real hardware data from multiple systems, the next stage should add a cloud database/API (for example Supabase or Firebase) or another IoT backend:

ESP32 #1 ─┐
ESP32 #2 ─┼──> Cloud API/database ──> GitHub Pages dashboard
ESP32 #3 ─┘              ↑
                         └── Website commands

For each physical system:
ESP32 -> Arduino -> sensors/relay -> pump/drip irrigation

Do not connect a pump directly to an ESP32/Arduino GPIO. Use an appropriate driver/relay module and suitable power supply, with adult/supervisor help for any higher-voltage equipment.

## Publishing this version
Replace the existing `index.html`, `style.css`, and `script.js` in the GitHub repository with the files from this folder, then commit the changes. GitHub Pages should automatically rebuild the site.
